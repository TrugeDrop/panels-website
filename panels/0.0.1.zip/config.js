module.exports = {
  dbURL: "mongodb+srv://PVCO:14-4_V@cluster0.kbfyq.mongodb.net/AoonramelMinecraft?retryWrites=true&w=majority",
  secret: "secret",
  port: 2912,
  admin: "2022"
}
