const express = require('express');
const app = express();
const config = require("./config");
const mongoose = require('mongoose');
const expressSession = require('express-session');
const bodyParser = require('body-parser');
const layout = require("express-ejs-layouts");
const flash = require('connect-flash');
const connectMongo = require('connect-mongo');
const expressFileUpload = require("express-fileupload");
const PORT = config.port || 3000;
const dbURL = config.dbURL;

app.use(expressFileUpload());
app.set('view engine', 'ejs'); 
app.use(bodyParser.urlencoded({extended: true}));
app.set("layout", "./inc/layout");
app.use(express.static("./public"));
app.use(layout);
app.use(flash());

app.use(expressSession({
  secret: config.secret,
  resave: false,
  saveUninitialized: true,
  store: connectMongo.create({ mongoUrl: dbURL })
}))

mongoose.connect(dbURL, {
  useNewUrlParser: true,
  useUnifiedTopology: true
})

.then(() => {
  app.listen(PORT, () => console.log('Site hazır !'));
})
.catch(() => {
console.log('Site hazır değil !')
});

app.use(require('./routers/main'));
app.use('/account', require('./routers/account'));
app.use('/manage', require('./routers/manage'));
app.use('/admin', require('./routers/admin'));
app.use('/posts', require('./routers/posts'));
app.use('/manage/server', require('./routers/file-manager/main'));

//404 sayfası
app.use(function (req, res, next) {
  res.status(404).send("Sayfa Bulunamadı !")
})
/*
//console
io.on('connection', (socket) => {
  socket.on('console', (serverid, consl) => {
  const Servers = require("./models/server");
  
  Servers.findById(serverid, function(err,server){
     //return io.emit('console', server.server_name)
      if(err || !server) return io.emit('console', "Bir hata oluştu!")
         
const util = require('minecraft-server-util');
const client = new util.RCON();

const connectOpts = {
    timeout: 1000 * 2
    // ... any other connection options specified by
    // NetConnectOpts in the built-in `net` Node.js module
};

const loginOpts = {
    timeout: 1000 * 2
};

(async () => {
    try{
    await client.connect(server.server_ip, server.rcon_port, connectOpts)
    await client.login(server.rcon_password, loginOpts);
    }catch (e){
      return io.emit('console', "Bağlantı hatası!");
    }
    
    const message = await client.execute(consl);
    await client.close();
    await io.emit('console', message);
})();
        });
  });
});
*/