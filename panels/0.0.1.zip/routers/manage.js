const express = require("express");
const router = express.Router();
const User = require("../models/user");
const Server = require("../models/server");
const config = require("../config");

router.get("/", (req,res) => {
  if(!req.session.userId) return res.redirect("/account/login");
  User.findById(req.session.userId, function(err,user){
    Server.find({ userid: user._id, active: true }, function(err,servers){
      res.render("manage/main", {title: "Manage", servers: servers, user: user, page: ["manage", "servers"]});
    });
  });
});

router.get("/server/:serverid", (req,res) => {
  if(!req.session.userId) return res.redirect("/account/login");
  User.findById(req.session.userId, function(err,user){
    Server.findById(req.params.serverid, function(err,server){
      if(err || !server || server.active == false) return res.send("Sunucu bulunamadı!");
      if(server.userid != user._id) return res.send("Bu sunucunun sahibi sen değilsin!");
      //minecraft server util
      const util = require("minecraft-server-util"); 
      util.queryFull(server.server_ip, server.query_port, { sessionID: 1, enableSRV: true })
      .then((result) => {
        res.render("manage/server", {title: "Server - "+server.server_name, server: server, user: user, server_stat: result, page: ["manage", "server", "console"]});
      })
      .catch(() => {
        res.render("manage/server", {title: "Server - "+server.server_name, server: server, user: user, server_stat: null, page: ["manage", "server", "console"]})
      });
    });
  });
});

/*

Sunucu Dosyaları Dahil Edildi: ./file-manager/main.js

*/

router.get("/server/:serverid/players", (req,res) => {
  if(!req.session.userId) return res.redirect("/account/login");
  User.findById(req.session.userId, function(err,user){
    Server.findById(req.params.serverid, function(err,server){
      if(err || !server || server.active == false) return res.send("Sunucu bulunamadı!");
      if(server.userid != user._id) return res.send("Bu sunucunun sahibi sen değilsin!");
      
      //Op and Ban Read File
      const fs = require("fs");
      var ops = "", bans = "";
      fs.readFile(server.dir+"ops.json", "utf8", function(err,data){
        try{
          let jsonData = JSON.parse(data);
          ops = jsonData;
        }catch (e) {
          return res.send("Bir hata oluştu!");
        }
      });
      
      fs.readFile(server.dir+"banned-players.json", "utf8", function(err,data){
        try{
          let jsonData = JSON.parse(data);
          bans = jsonData;
        }catch (e) {
          return res.send("Bir hata oluştu!");
        }
      });
      
      //minecraft server util
      const util = require("minecraft-server-util"); 
      util.queryFull(server.server_ip, server.query_port, { sessionID: 1, enableSRV: true })
      .then((result) => {
        res.render("manage/players", {title: "Oyuncular - "+server.server_name, server: server, user: user, players: result.players, page: ["manage", "server", "players"], ops: ops, bans: bans});
      })
      .catch(() => {
        res.render("manage/players", {title: "Oyuncular - "+server.server_name, server: server, user: user, players: null, page: ["manage", "server", "players"], ops: ops, bans: bans})
      });
    });
  });
});

router.get("/server/:serverid/plugins", (req,res) => {
  if(!req.session.userId) return res.redirect("/account/login");
  User.findById(req.session.userId, function(err,user){
    Server.findById(req.params.serverid, function(err,server){
      if(err || !server) return res.send("Sunucu bulunamadı!");
      if(server.userid != user._id) return res.send("Bu sunucunun sahibi sen değilsin!");
      const request = require('request');
      if(req.query.name) {
        request('http://localhost:3700/plugin-get/user/627119b34b2fdd5e182df7d0/plugin/'+req.query.name, function (error, response, body) {
        try{
          var pl = JSON.parse(body);
        }catch (e) {
          return res.send("Bir hata oluştu!");
        };
        res.render("manage/server-plugin", {title: "Eklenti - "+server.server_name, server: server, user: user, page: ["manage", "server", "plugins"], pl: pl});
        });
      }else{
      request('http://localhost:3700/plugin-get/user/627119b34b2fdd5e182df7d0/plugins', function (error, response, body) {
        try{
          var pls = JSON.parse(body);
        }catch (e) {
          return res.send("Bir hata oluştu!");
        };
      res.render("manage/server-plugins", {title: "Eklentiler - "+server.server_name, server: server, user: user, page: ["manage", "server", "plugins"], pls: pls});
      });
      }
    });
  });
});

router.get("/server/:serverid/settings", (req,res) => {
  if(!req.session.userId) return res.redirect("/account/login");
  User.findById(req.session.userId, function(err,user){
    Server.findById(req.params.serverid, function(err,server){
      if(err || !server) return res.send("Sunucu bulunamadı!");
      if(server.userid != user._id) return res.send("Bu sunucunun sahibi sen değilsin!");
      res.render("manage/server-settings", {title: "Sunucu Ayarları - "+server.server_name, server: server, user: user, page: ["manage", "server", "settings"]});
    });
  });
});

router.post("/server/:serverid/settings/edit/server-name", (req,res) => {
  if(!req.session.userId) return res.redirect("/account/login");
  User.findById(req.session.userId, function(err,user){
    Server.findById(req.params.serverid, function(err,server){
      if(err || !server) return res.send("Sunucu bulunamadı!");
      if(server.userid != user._id) return res.send("Bu sunucunun sahibi sen değilsin!");
      
      server.server_name = req.body.server_name;
      
      server.save(function(err){
        if(err) return res.send("Bir hata oluştu!");
        res.redirect("/manage/server/"+server._id+"/settings");
      });
    });
  });
});

router.post("/server/plugin/add", function(req, res) {
  if (!req.session.userId) return res.redirect("/account/login");
  User.findById(req.session.userId, function(err, user) {
    Server.findById(req.body.serverid, function(err, server) {
      if (err || !server) return res.send("Sunucu bulunamadı!");
      if (server.userid != user._id) return res.send("Bu sunucunun sahibi sen değilsin!");
      const request = require("request");
      request('http://localhost:3700/plugin-get/user/627119b34b2fdd5e182df7d0/plugin/'+req.body.plname+'/version/'+req.body.plversion, function (error, response, body) {
        try{
          var pls = JSON.parse(body);
        }catch (e) {
          return res.json({ result: "error" });
        };

        const { DownloaderHelper } = require('node-downloader-helper');
        
        var options = {
          override:true
        }
        
        const dl = new DownloaderHelper(pls.url , server.dir+"plugins", options);
        dl.on('end', () => res.json({ result: "success" }));
        dl.on('error', () => res.json({ result: "error" }));
        dl.start();
      });
    });
  });
});

module.exports = router;
