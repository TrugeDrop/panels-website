const express = require("express");
const router = express.Router();
const config = require('../config');
const Server = require('../models/server');

function cmdUtil(server, cmd, callback){
  const util = require('minecraft-server-util');
  const client = new util.RCON();
  const connectOpts = { timeout: 1000 * 5 };
  const loginOpts = { timeout: 1000 * 5 };
  
    (async () => {
      try {
      await client.connect(server.server_ip, server.rcon_port, connectOpts);
      await client.login(server.rcon_password, loginOpts);
    
      const result = await client.execute(cmd);
      await client.close();
      
      return callback(result);
     }catch (e) {
     console.log("Command Util Function Error:\n"+e);
     }
    })();
};

router.post('/command', function(req,res){
  let { serverid, command } = req.body;
  
	if(!req.session.userId) return res.redirect("/account/login");
	
   Server.findById(serverid, function(err,server){
   
   if(!server) return res.send('Bir hata oluştu!');
   if(server.userid != req.session.userId) return res.send("Bu sunucu sana ait değil!");
     
     cmdUtil(server, command, function(result){
      return res.json({result: result});
    });
  });
});

router.post("/command/op/add", function(req,res){
  let { serverid, player } = req.body;
  
	if(!req.session.userId) return res.redirect("/account/login");
	
   Server.findById(serverid, function(err,server){
   
   if(!server) return res.send('Bir hata oluştu!');
   if(server.userid != req.session.userId) return res.send("Bu sunucu sana ait değil!");
    
    cmdUtil(server, `op ${player}`, function(){
      return res.json({});
    });
  });
});

router.post("/command/op/remove", function(req,res){
  let { serverid, player } = req.body;
  
	if(!req.session.userId) return res.redirect("/account/login");
	
   Server.findById(serverid, function(err,server){
   
   if(!server) return res.send('Bir hata oluştu!');
   if(server.userid != req.session.userId) return res.send("Bu sunucu sana ait değil!");
    
     cmdUtil(server, `deop ${player}`, function(){
      return res.json({});
     });
  });
});

router.post("/command/ban/add", function(req,res){
  let { serverid, player } = req.body;
  
	if(!req.session.userId) return res.redirect("/account/login");
	
   Server.findById(serverid, function(err,server){
   
   if(!server) return res.send('Bir hata oluştu!');
   if(server.userid != req.session.userId) return res.send("Bu sunucu sana ait değil!");
     
    cmdUtil(server, `ban ${player}`, function(){
      return res.json({});
    });
  });
});

router.post("/command/ban/remove", function(req,res){
  let { serverid, player } = req.body;
  
	if(!req.session.userId) return res.redirect("/account/login");
	
   Server.findById(serverid, function(err,server){
   
   if(!server) return res.send('Bir hata oluştu!');
   if(server.userid != req.session.userId) return res.send("Bu sunucu sana ait değil!");
     
    cmdUtil(server, `pardon ${player}`, function(){
      return res.json({});
    });
  });
});

router.post('/status', function(req,res){
	if(!req.session.userId) return res.redirect("/account/login");
	
   Server.findById(req.body.serverid, function(err,server){
   
   if(!server) return res.send('Bir hata oluştu!');
   if(server.userid != req.session.userId) return res.send("Bu sunucu sana ait değil!");
   
var osu = require("node-os-utils");
var os = require('os');

osu.cpu.usage()
  .then(info => {
    let totalmem = (os.totalmem() * 0.000001).toFixed();
    let freemem = (os.freemem() * 0.000001).toFixed();
    return res.json({cpu: info, freemem: freemem, totalmem: totalmem});
  });
   });
});

module.exports = router;
