const express = require("express");
const router = express.Router();
const User = require("../models/user");
const Server = require("../models/server");
const config = require("../config");

router.get("/", (req,res) => {
  if(!req.session.userId) return res.redirect("/account/login");
  User.findById(req.session.userId, function(err,user){
    if(user.auth.indexOf('admin') == -1) return res.send("Yetersiz yetki!");
      res.render("admin/main", {title: "Yönetici", user: user, page: []})
  });
});

router.get("/servers", (req, res) => {
  if (!req.session.userId) return res.redirect("/account/login");
  User.findById(req.session.userId, function(err, user) {
    if (user.auth.indexOf('admin') == -1) return res.send("Yetersiz yetki!");
    Server.find({}, function(err,servers){
      res.render("admin/servers", { title: "Yönetici - Sunucular", user: user, servers: servers, page: []});
    });
  });
});

router.get("/servers/create", (req, res) => {
  if (!req.session.userId) return res.redirect("/account/login");
  User.findById(req.session.userId, function(err, user) {
    if (user.auth.indexOf('admin') == -1) return res.send("Yetersiz yetki!");
    User.find({}, function(err,users){
      res.render("admin/create-server", { title: "Yönetici - Sunucu Oluştur", user: user, users: users, page: []});
    });
  });
});

router.post("/servers/create", (req, res) => {
  if (!req.session.userId) return res.redirect("/account/login");
  User.findById(req.session.userId, function(err, user) {
    if (user.auth.indexOf('admin') == -1) return res.send("Yetersiz yetki!");
    let { server_name, userid, server_ip, server_port, rcon_port, rcon_password, query_port, dir } = req.body;
    
    const server = new Server(req.body);
    
    server.save(function(err){
      if(err) return res.send("Bir hata oluştu!");
      res.redirect("/admin/servers");
    });
  });
});

router.post("/server/:serverid/edit", (req, res) => {
  if (!req.session.userId) return res.redirect("/account/login");
  User.findById(req.session.userId, function(err, user) {
    if (user.auth.indexOf('admin') == -1) return res.send("Yetersiz yetki!");
    Server.findById(req.params.serverid, function(err, server) {
      if (err || !server) return res.send("Bir hata oluştu!");
      
      let { server_name, userid, server_ip, server_port, rcon_port, rcon_password, query_port, dir, active } = req.body;
      
      server.server_name = server_name;
      server.userid = userid;
      server.server_ip = server_ip;
      server.server_port = server_port;
      server.rcon_port = rcon_port;
      server.rcon_password = rcon_password;
      server.query_port = query_port;
      server.dir = "../servers/"+dir;
      server.active = Boolean(active === 'true');
      
      server.save(function(err){
        if(err) return res.send("Bir hata oluştu!");
        res.redirect("/admin/server/"+server._id);
      });
    });
  });
});

router.get("/server/:serverid/delete", (req,res) => {
  if (!req.session.userId) return res.redirect("/account/login");
  User.findById(req.session.userId, function(err, user) {
    if (user.auth.indexOf('admin') == -1) return res.send("Yetersiz yetki!");
    Server.findByIdAndDelete(req.params.serverid, function(err,server){
      if(err || !server) return res.send("Bir hata oluştu!");
      res.redirect("/admin/servers");
    });
  });
});

router.get("/server/:serverid", (req,res) => {
  if (!req.session.userId) return res.redirect("/account/login");
  User.findById(req.session.userId, function(err, user) {
    if (user.auth.indexOf('admin') == -1) return res.send("Yetersiz yetki!");
    Server.findById(req.params.serverid, function(err,server){
      if(err || !server) return res.send("Bir hata oluştu!");
     User.find({}, function(err,users){
      res.render("admin/server", { title: `Admin - Server ${ server.server_name }`, user: user, server: server, users: users, page: []});
      });
    });
  });
});

router.get("/users", (req, res) => {
  if (!req.session.userId) return res.redirect("/account/login");
  User.findById(req.session.userId, function(err, user) {
    if (user.auth.indexOf('admin') == -1) return res.send("Yetersiz yetki!");
    User.find({}, function(err,users){
      res.render("admin/users", { title: "Yönetici - Kullanıcılar", user: user, users: users, page: []});
    });
  });
});

router.get("/user/:userid/delete", (req, res) => {
  if (!req.session.userId) return res.redirect("/account/login");
  User.findById(req.session.userId, function(err, user) {
    if (user.auth.indexOf('admin') == -1) return res.send("Yetersiz yetki!");
    if (user._id == req.session.userId || user.auth.indexOf('admin') != -1) return res.send("Kendi hesabını veya bir başka yönetici hesabını silemezsin! Eğer gerçekten silmek istiyorsan bu işlemi <b>Veri Tabanından</b> yapmalısın.");
    User.findByIdAndDelete(req.params.userid, function(err,user2){
      if(err || !user) return res.send("Bir hata oluştu!");
      res.redirect("/admin/users");
    });
  });
});

router.get("/user/:userid", (req, res) => {
  if (!req.session.userId) return res.redirect("/account/login");
  User.findById(req.session.userId, function(err, user) {
    if (user.auth.indexOf('admin') == -1) return res.send("Yetersiz yetki!");
    User.findById(req.params.userid, function(err,user2){
      if(err || !user) return res.send("Bir hata oluştu!");
      res.render("admin/user", { title: `Admin - User ${ user2.username }`, user: user, u: user2, page: []});
    });
  });
});

router.post("/user/:userid/edit", (req, res) => {
  if (!req.session.userId) return res.redirect("/account/login");
  User.findById(req.session.userId, function(err, user) {
    if (user.auth.indexOf('admin') == -1) return res.send("Yetersiz yetki!");
    User.findById(req.params.userid, function(err,user2){
      if(err || !user) return res.send("Bir hata oluştu!");
      let { username, password, email, active } = req.body;
      
      user2.username = username;
      user2.password = password;
      user2.email = email;
      user2.active = Boolean(active === 'true');
      
      user2.save(function(err){
        if(err) return res.send("Bir hata oluştu!");
        res.redirect("/admin/user/"+user2._id);
      });
    });
  });
});


module.exports = router;
