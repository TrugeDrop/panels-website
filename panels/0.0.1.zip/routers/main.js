const express = require("express");
const router = express.Router();
const Server = require('../models/server');
const util = require('minecraft-server-util');

/*
router.get("/", (req,res)=>{
    if(req.session.serverId){
        Server.findById(req.session.serverId, function(err,server){
        if(err) return res.send('Bir hata oluştu!');
        //minecraft server util
        const options = {
          sessionID: 1,
          enableSRV: true
        };    
        util.queryBasic(server.server_ip, server.query_port, options)
        .then((result) => res.render("index", {title: "Ana Sayfa", server: server, query: result, console: req.flash('console'), istek: req.flash('konsol-istek')}))
        .catch(() => res.send('Bir hata oluştu!'));
        })
    }else{
        res.render('login', {title: "Giriş Yap"})
    }
});*/

router.get('/', (req,res) => {
  if(!req.session.userId) return res.redirect("/account/login");
  res.redirect("/manage");
});

module.exports = router;
