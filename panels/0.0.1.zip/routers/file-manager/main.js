const express = require("express");
const router = express.Router();
const fs = require("fs");
const file = require("./controller/file");
const folder = require("./controller/folder");
const path = require("path");
const User = require("../../models/user");
const Server = require("../../models/server");

/*
router.get("/server/:serverid/files", (req,res) => {
  if(!req.session.userId) return res.redirect("/account/login");
  User.findById(req.session.userId, function(err,user){
    Server.findById(req.params.serverid, function(err,server){
      if(err || !server) return res.send("Sunucu bulunamadı!");
      if(server.userid != user._id) return res.send("Bu sunucunun sahibi sen değilsin!");
      res.render("manage/server-files", {title: "Sunucu Dosyaları - "+server.server_name, server: server, user: user, page: "dosyalar"});
    });
  });
});
*/

function cont(req, res, callback) {
  if(!req.session.userId) return res.redirect("/account/login");
  User.findById(req.session.userId, function(err,user){
    Server.findById(req.params.serverid, function(err,server){
      if(err || !server) return res.send("Sunucu bulunamadı!");
      if(server.userid != user._id) return res.send("Bu sunucunun sahibi sen değilsin!");
      
      return callback(user, server)
    });
  });
};

router.get("/:serverid/files", (req,res) => {
  cont(req, res, function(user, server){
  fs.readdir(server.dir, {withFileTypes: true}, function(err,files){
    if(err) return res.send("Error!");
    
   var new_files = files.map(filesFunc);
   function filesFunc(value, indeks, arr){
      return {
        name: value.name,
        isFile: value.isFile(),
        isDirectory: value.isDirectory(),
        extname: path.extname(server.dir+value.name),
        size: (fs.statSync(server.dir+value.name).size * 0.000000125).toFixed(4)
      }
   }
    res.render("manage/file-manager/index", {files: new_files, folder: null, title: `Dosya Yöneticisi - ${server.server_name}`, user: user, server: server, page: ["manage", "server", "files"]})
  });
  });
});

//Folder
router.get("/:serverid/files/folder/:folder", folder.folder);
router.get("/:serverid/files/delete-folder/:folder", folder.delete_folder);
router.get("/:serverid/files/new-folder", folder.new_folder);
router.get("/:serverid/files/new-folder/:folder/", folder.new_folder_folder);
router.post("/:serverid/files/new-folder", folder.new_folder_post);
router.post("/:serverid/files/new-folder/:folder/", folder.new_folder_folder_post);

//File
router.get("/:serverid/files/file/:file", file.file);
router.get("/:serverid/files/file/:folder/:file", file.file_folder);
router.get("/:serverid/files/delete-file/:file", file.delete_file);
router.get("/:serverid/files/delete-file/:folder/:file", file.delete_folder_file);
router.get("/:serverid/files/new-file", file.new_file);
router.get("/:serverid/files/new-file/:folder/", file.new_folder_file);
router.post("/:serverid/files/new-file", file.new_file_post);
router.post("/:serverid/files/new-file/:folder/", file.new_folder_file_post);
router.post("/:serverid/files/edit-file/:file", file.edit_file_post);
router.post("/:serverid/files/edit-file/:folder/:file", file.edit_folder_file_post);
router.get("/:serverid/files/copy-file/:file/paste/:paste", file.copy_file);
router.get("/:serverid/files/copy-file/:folder/:file/paste/:paste", file.copy_folder_file);
router.get("/:serverid/files/copy-file/:folder/:file/paste", file.copy_file_maindir);
router.get("/:serverid/files/download-file/:file", file.download_file);
router.get("/:serverid/files/download-file/:folder/:file", file.download_folder_file);
router.get("/:serverid/files/file-upload", file.file_upload);
router.get("/:serverid/files/file-upload/:folder", file.file_upload_folder);
router.post("/:serverid/files/file-upload", file.file_upload_post);
router.post("/:serverid/files/file-upload/:folder", file.file_upload_folder_post);
router.get("/:serverid/files/unarchive/:file", file.unarchive);
router.get("/:serverid/files/unarchive/:folder/:file", file.folder_unarchive);

//Rename file and folder
router.get("/:serverid/files/rename/:type/:file", file.rename_file);
router.get("/:serverid/files/rename/:type/:folder/:file", file.rename_folder_file);
router.post("/:serverid/files/rename/:type/:file", file.rename_file_post);
router.post("/:serverid/files/rename/:type/:folder/:file", file.rename_folder_file_post);

module.exports = router;
