const fs = require("fs");
const User = require("../../../models/user");
const Server = require("../../../models/server");

function cont(req, res, callback) {
  if(!req.session.userId) return res.redirect("/account/login");
  User.findById(req.session.userId, function(err,user){
    Server.findById(req.params.serverid, function(err,server){
      if(err || !server) return res.send("Sunucu bulunamadı!");
      if(server.userid != user._id) return res.send("Bu sunucunun sahibi sen değilsin!");
      
      return callback(user, server)
    });
  });
};

//View file
var file = (req,res) => {
  cont(req, res, function(user, server){
  fs.readFile(server.dir+req.params.file, "UTF-8", function(err,file){
    if(err) return res.send("Error!");
    res.render("manage/file-manager/pages/file", {filename: req.params.file, file: file, folder: null, user: user, title: `Dosya Yöneticisi - ${server.server_name}`, server: server, page: ["manage", "server", "files"]});
  });
  });
};

//View file inside folder
var file_folder = (req,res) => {
  cont(req, res, function(user, server){
  const result = req.params.folder.split("---")
  var new_result = server.dir;
  result.forEach(rest => {
    new_result+=rest+"/";
  })
  fs.readFile(new_result+req.params.file, "UTF-8", function(err,file){
    if(err) return res.send("Error!");
    res.render("manage/file-manager/pages/file", {filename: req.params.file, file: file, folder: req.params.folder, user: user, title: `Dosya Yöneticisi - ${server.server_name}`, server: server, page: ["manage", "server", "files"]});
  });
});
};

//Edit file post
var edit_file_post = (req,res) => {
  cont(req, res, function(user, server){
  fs.writeFile(server.dir+req.params.file, req.body.file_content, function(err){
    if(err) return res.send("Error!");
    res.redirect(`/manage/server/${ server._id }/files`+"/file/"+req.params.file);
  });
  });
};

//Edit file inside folder
var edit_folder_file_post = (req,res) => {
  cont(req, res, function(user, server){
  const result = req.params.folder.split("---")
  var new_result = server.dir;
  result.forEach(rest => {
    new_result+=rest+"/";
  });
  fs.writeFile(new_result+req.params.file, req.body.file_content, function(err,file){
    if(err) return res.send("Error!");
    res.redirect(`/manage/server/${ server._id }/files`+"/file/"+req.params.folder+"/"+req.params.file);
  });
  });
};

//Delete file
var delete_file = (req,res) => {
  cont(req, res, function(user, server){
  fs.unlink(server.dir+req.params.file, function(err,file){
    if(err) return res.send("Error!");
    res.redirect(`/manage/server/${ server._id }/files`);
  });
  });
};

//Delete the file inside the folder
var delete_folder_file = (req,res) => {
  cont(req, res, function(user, server){
  const result = req.params.folder.split("---")
  var new_result = server.dir;
  result.forEach(rest => {
    new_result+=rest+"/";
  })
  fs.unlink(new_result+req.params.file, function(err,file){
    if(err) return res.send("Error!");
    res.redirect(`/manage/server/${ server._id }/files`+"/folder/"+req.params.folder);
  });
  });
};

//New File
var new_file = (req,res) => {
  cont(req, res, function(user, server){
    res.render("manage/file-manager/pages/new-file", {folder: null, user: user, title: `Dosya Yöneticisi - ${server.server_name}`, server: server, page: ["manage", "server", "files"]})
  });
};

var new_folder_file = (req,res) => {
  cont(req, res, function(user, server){
    res.render("manage/file-manager/pages/new-file", {folder: req.params.folder, user: user, title: `Dosya Yöneticisi - ${server.server_name}`, server: server, page: ["manage", "server", "files"]});
  });
};

var new_file_post = (req,res) => {
  cont(req, res, function(user, server){
    fs.writeFile(server.dir+req.body.file_name, req.body.file_content, function(err){
      if(err) return res.send("Error!");
      res.redirect(`/manage/server/${ server._id }/files`);
    });
  });
};

var new_folder_file_post = (req,res) => {
  cont(req, res, function(user, server){
  const result = req.params.folder.split("---")
  var new_result = server.dir;
  result.forEach(rest => {
    new_result+=rest+"/";
  })
  fs.writeFile(new_result+req.body.file_name, req.body.file_content, function(err){
    if(err) return res.send("Error!");
    res.redirect(`/manage/server/${ server._id }/files`+"/folder/"+req.params.folder);
  });
  });
};

//Rename file and folder
var rename_file = (req,res) => {
  cont(req, res, function(user, server){
    res.render("manage/file-manager/pages/rename", {folder: null, filename: req.params.file, type: req.params.type, user: user, title: `Dosya Yöneticisi - ${server.server_name}`, server: server, page: ["manage", "server", "files"]});
  });
};

var rename_folder_file = (req,res) => {
  cont(req, res, function(user, server){
    res.render("manage/file-manager/pages/rename", {folder: req.params.folder, filename: req.params.file, type: req.params.type, user: user, title: `Dosya Yöneticisi - ${server.server_name}`, server: server, page: ["manage", "server", "files"]});
  });
};

var rename_file_post = (req,res) => {
  cont(req, res, function(user, server){
  fs.rename(server.dir+req.params.file, server.dir+req.body.file_name, function(err){
    if(err) return res.send("Error!");
    res.redirect(`/manage/server/${ server._id }/files`);
  });
  });
};

var rename_folder_file_post = (req,res) => {
  cont(req, res, function(user, server){
  const result = req.params.folder.split("---")
  var new_result = server.dir;
  result.forEach(rest => {
    new_result+=rest+"/";
  });
  fs.rename(new_result+req.params.file, new_result+req.body.file_name, function(err){
    if(err) return res.send("Error!");
    res.redirect(`/manage/server/${ server._id }/files`+"/folder/"+req.params.folder)
  });
  });
};

var copy_file_maindir = (req,res) => {
  cont(req, res, function(user, server){
  let {folder, file} = req.params;
  const result = folder.split("---")
  var new_result = server.dir;
  result.forEach(rest => {
    new_result+=rest+"/";
  });
  fs.copyFile(new_result+file, server.dir+file, function(err){
    if(err) return res.send("Error!");
    res.redirect(`/manage/server/${ server._id }/files`);
  });
  });
};

var copy_file = (req,res) => {
  cont(req, res, function(user, server){
  let {file, paste} = req.params;
  const result = paste.split("---")
  var new_result = server.dir;
  result.forEach(rest => {
    new_result+=rest+"/";
  });
  fs.copyFile(server.dir+file, new_result+file, function(err){
    if(err) return res.send("Error!");
    res.redirect(`/manage/server/${ server._id }/files`+"/folder/"+paste);
  });
});
};

var copy_folder_file = (req,res) => {
  cont(req, res, function(user, server){
  let {folder, file, paste} = req.params;
  const result_folder = folder.split("---")
  var new_result_folder = server.dir;
  result_folder.forEach(rest => {
    new_result_folder+=rest+"/";
  });
  const result_paste = paste.split("---")
  var new_result_paste = server.dir;
  result_paste.forEach(rest => {
    new_result_paste+=rest+"/";
  });
  fs.copyFile(new_result_folder+file, new_result_paste+file, function(err){
    if(err) return res.send("Error!");
    res.redirect(`/manage/server/${ server._id }/files`+"/folder/"+paste)
  });
  });
};

var download_file = (req,res) => {
  cont(req, res, function(user, server){
    res.download(server.dir+req.params.file);
  });
};

var download_folder_file = (req,res) => {
  cont(req, res, function(user, server){
  let {folder, file} = req.params;
  const result = folder.split("---")
  var new_result = server.dir;
  result.forEach(rest => {
    new_result+=rest+"/";
  });
  res.download(new_result+req.params.file);
  });
};

var file_upload = (req,res) => {
  cont(req, res, function(user, server){
    res.render("manage/file-manager/pages/file-upload", {folder: null, user: user, server: server, title: "Dosya Yönetici - "+server.server_name, page: ["manage", "server", "files"]});
  });
};

var file_upload_folder = (req,res) => {
  cont(req, res, function(user, server){
    res.render("manage/file-manager/pages/file-upload", {folder: req.params.folder, user: user, server: server, title: "Dosya Yönetici - "+server.server_name, page: ["manage", "server", "files"]});
  });
};

var file_upload_post = (req,res) => {
  cont(req, res, function(user, server){
  const path = require("path");
  const file = req.files.file;
  file.mv(path.resolve(__dirname, "../../../"+server.dir, file.name))
  .then(() => res.redirect(`/manage/server/${ server._id }/files`))
  .catch(() => res.send("Error!"));
  });
};

var file_upload_folder_post = (req,res) => {
  cont(req, res, function(user, server){
  const result = req.params.folder.split("---")
  var new_result = "../../../"+server.dir;
  result.forEach(rest => {
    new_result+=rest+"/";
  });
  const path = require("path");
  const file = req.files.file;
  file.mv(path.resolve(__dirname, new_result, file.name))
  .then(() => res.redirect(`/manage/server/${ server._id }/files`+"/folder/"+req.params.folder))
  .catch(() => res.send("Error!"));
  });
};

var unarchive = (req,res) => {
  cont(req, res, function(user, server){
  const unzip = require("unzipper");
  fs.createReadStream(server.dir+req.params.file).pipe(unzip.Extract({ path: server.dir }));
  setTimeout(() => res.redirect(`/manage/server/${ server._id }/files`), 500);
  });
};

var folder_unarchive = (req,res) => {
  cont(req, res, function(user, server){
  const result = req.params.folder.split("---")
  var new_result = server.dir;
  result.forEach(rest => {
    new_result+=rest+"/";
  });
  const unzip = require("unzipper");
  fs.createReadStream(new_result+req.params.file).pipe(unzip.Extract({ path: new_result }));
  setTimeout(() => res.redirect(`/manage/server/${ server._id }/files`+"/folder/"+req.params.folder), 500);
  });
};

module.exports = {
  file: file,
  file_folder: file_folder,
  edit_file_post: edit_file_post,
  edit_folder_file_post: edit_folder_file_post,
  delete_file: delete_file,
  delete_folder_file: delete_folder_file,
  new_file: new_file,
  new_folder_file: new_folder_file,
  new_file_post: new_file_post,
  new_folder_file_post: new_folder_file_post,
  rename_file: rename_file,
  rename_folder_file: rename_folder_file,
  rename_file_post: rename_file_post,
  rename_folder_file_post: rename_folder_file_post,
  copy_file: copy_file,
  copy_folder_file: copy_folder_file,
  copy_file_maindir: copy_file_maindir,
  download_file: download_file,
  download_folder_file: download_folder_file,
  file_upload: file_upload,
  file_upload_folder: file_upload_folder,
  file_upload_post: file_upload_post,
  file_upload_folder_post: file_upload_folder_post,
  unarchive: unarchive,
  folder_unarchive: folder_unarchive
};
