const fs = require("fs");
const User = require("../../../models/user");
const Server = require("../../../models/server");

function cont(req, res, callback) {
  if(!req.session.userId) return res.redirect("/account/login");
  User.findById(req.session.userId, function(err,user){
    Server.findById(req.params.serverid, function(err,server){
      if(err || !server) return res.send("Sunucu bulunamadı!");
      if(server.userid != user._id) return res.send("Bu sunucunun sahibi sen değilsin!");
      
      return callback(user, server)
    });
  });
};

var folder = (req,res) => {
  cont(req, res, function(user, server){
  const path = require("path");
  const result = req.params.folder.split("---")
  var new_result = server.dir;
  result.forEach(rest => {
    new_result+=rest+"/";
  })
  fs.readdir(new_result, {withFileTypes: true}, function(err,files){
    if(err) return res.send("Error!");
    
    var new_files = files.map(filesFunc);
   function filesFunc(value, indeks, arr){
      return {
        name: value.name,
        isFile: value.isFile(),
        isDirectory: value.isDirectory(),
        extname: path.extname(server.dir+value.name),
        size: (fs.statSync(new_result+value.name).size * 0.000000125).toFixed(9)
      }
   }
   
    res.render("manage/file-manager/index", {files: new_files, folder: req.params.folder, user: user, title: `Dosya Yöneticisi - ${server.server_name}`, server: server, page: ["manage", "server", "files"]})
  });
  });
};

var delete_folder = (req,res) => {
  cont(req, res, function(user, server){
  const result = req.params.folder.split("---")
  var new_result = server.dir;
  result.forEach(rest => {
    new_result+=rest+"/";
  });
  fs.rm(new_result, { recursive: true }, function(err){
    if(err) return res.send("Error! \n"+err);
    if(result.length == 1){
      res.redirect(`/manage/server/${server._id}/files`);
    }else{
      let new_folder = req.params.folder.split("---")
      new_folder.pop();
      let new_f = "";
      new_folder.forEach(rest => {
        if(new_folder.length == 1){
          new_f+=rest
        }else{
          if(new_folder[0] == rest) return new_f+=rest;
          new_f+="-"+rest
        }
     });
      res.redirect(`/manage/server/${server._id}/files`+"/folder/"+new_f);
    }
  });
  });
};

var new_folder = (req,res) => {
  cont(req, res, function(user, server){
  res.render("manage/file-manager/pages/new-folder", {folder: null, user: user, title: `Dosya Yöneticisi - ${server.server_name}`, server: server, page: ["manage", "server", "files"]})
});
};

var new_folder_folder = (req,res) => {
  cont(req, res, function(user, server){
  res.render("manage/file-manager/pages/new-folder", {folder: req.params.folder, user: user, title: `Dosya Yöneticisi - ${server.server_name}`, server: server, page: ["manage", "server", "files"]});
  });
};

var new_folder_post = (req,res) => {
  cont(req, res, function(user, server){
  fs.mkdir(server.dir+req.body.folder_name, function(err){
    if(err) return res.send("Error!");
    res.redirect(`/manage/server/${server._id}/files`);
  });
  });
};

var new_folder_folder_post = (req,res) => {
  cont(req, res, function(user, server){
  const result = req.params.folder.split("---")
  var new_result = server.dir;
  result.forEach(rest => {
    new_result+=rest+"/";
  })
  fs.mkdir(new_result+req.body.folder_name, function(err){
    if(err) return res.send("Error!");
    res.redirect(`/manage/server/${server._id}/files`+"/folder/"+result);
  });
  });
};

module.exports = {
  folder: folder,
  delete_folder: delete_folder,
  new_folder: new_folder,
  new_folder_folder: new_folder_folder,
  new_folder_post: new_folder_post,
  new_folder_folder_post: new_folder_folder_post
};
