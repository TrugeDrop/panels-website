const mongoose = require("mongoose");
const Schema = new mongoose.Schema({
  	server_name: {
        type: String,
        required: true,
        unique: true
    },
    userid: {
      type: String,
      required: true
    },
    server_ip: {
      type: String,
      required: true,
      unique: true
    },
    server_port: {
      type: Number,
      required: true,
      unique: true
    },
    rcon_port: {
        type: Number,
        required: true,
        unique: true
    },
    rcon_password: {
        type: String,
        required: true,
        unique: true
    },
    query_port: {
        type: Number,
        required: true,
        unique: true
    },
    dir: {
      type: String,
      required: true,
      unique: true
    },
    active: {
      type: Boolean,
      required: true,
      default: true
    }
}, { timestamps: true });

module.exports = mongoose.model("server", Schema);
